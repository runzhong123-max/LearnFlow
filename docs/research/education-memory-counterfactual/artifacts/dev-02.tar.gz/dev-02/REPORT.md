# 教育记忆等信息反事实实验（自动执行）

样本 24 条、反事实对 12 对；实际响应 192/192。

|预算单位|配置|完整输出正确|下一步正确|规范记录全入包|模型成功|
|---|---|---|---|---|---|
|2200|five_kernel_gated|22/24|24/24|0/24|24/24|
|2200|flat_gated|22/24|24/24|0/24|24/24|
|2200|five_kernel_source|18/24|24/24|0/24|24/24|
|2200|flat_source|2/24|24/24|0/24|24/24|
|8000|five_kernel_gated|20/24|22/24|24/24|22/24|
|8000|flat_gated|21/24|24/24|24/24|24/24|
|8000|five_kernel_source|16/24|22/24|24/24|22/24|
|8000|flat_source|8/24|24/24|24/24|24/24|

结果依据独立自动规则核验，不能称为教师认可、教学质量或学习增益。完整指标、错误记录及分组差值见 aggregate.json、scored.jsonl.gz 与 pairs.jsonl。

原始数据与代码审计：{"artifact_drift":[],"ok":true,"source_drift":[]}
实际模型用量：{"completion_tokens":15640,"prompt_cache_hit_tokens":406016,"prompt_cache_miss_tokens":237520,"prompt_tokens":643536,"total_tokens":659176}
