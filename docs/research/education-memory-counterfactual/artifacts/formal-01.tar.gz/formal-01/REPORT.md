# 教育记忆等信息反事实实验（自动执行）

样本 96 条、反事实对 48 对；实际响应 768/768。

|预算单位|配置|完整输出正确|下一步正确|规范记录全入包|模型成功|
|---|---|---|---|---|---|
|2200|five_kernel_gated|86/96|94/96|0/96|94/96|
|2200|flat_gated|88/96|96/96|0/96|96/96|
|2200|five_kernel_source|66/96|89/96|0/96|89/96|
|2200|flat_source|11/96|96/96|0/96|96/96|
|8000|five_kernel_gated|81/96|89/96|96/96|89/96|
|8000|flat_gated|84/96|96/96|96/96|96/96|
|8000|five_kernel_source|65/96|89/96|96/96|89/96|
|8000|flat_source|18/96|93/96|96/96|93/96|

结果依据独立自动规则核验，不能称为教师认可、教学质量或学习增益。完整指标、错误记录及分组差值见 aggregate.json、scored.jsonl.gz 与 pairs.jsonl。

原始数据与代码审计：{"artifact_drift":[],"ok":true,"source_drift":[]}
实际模型用量：{"completion_tokens":62816,"prompt_cache_hit_tokens":1608573,"prompt_cache_miss_tokens":938947,"prompt_tokens":2547520,"total_tokens":2610336}
